/**
 * data.js — Données de la carte Rush Action Game
 * Modifiez ce fichier pour mettre à jour les produits et prix.
 * Après modification, commitez sur GitHub → le site se met à jour automatiquement.
 */

const MENU_DATA = {

  config: {
    nom_etablissement: "Rush Action Game",
    badge: "🌿 Boissons locales & produits de qualité",
    titre: "Notre Carte",
    sous_titre: "Boissons & Snacking — Sélection éco-responsable",
    footer: "Une sélection locale & responsable, avec amour 🌿",
    mot_de_passe_edition: "!Rush123!"
  },

  fournisseurs: {
    SM:  { nom: "Sterne & Mousse",         localisation: "Rochefort-sur-Loire (49190)", bio: true,  logo: "assets/logos/SM.png" },
    CV:  { nom: "Château de la Viaudière", localisation: "Champ-sur-Layon (49380)",    bio: true,  logo: "assets/logos/CV.png" },
    BB:  { nom: "Bibibulles",              localisation: "Doué-en-Anjou (49700)",       bio: true,  logo: "assets/logos/BB.png" },
    MS:  { nom: "Maison Specht",           localisation: "Mantes-la-Jolie (78200)",     bio: false, logo: "assets/logos/MS.png" },
    FC:  { nom: "Flavie's & Co",           localisation: "Plérin (22190)",              bio: false, logo: "assets/logos/FC.png" },
    SC:  { nom: "So Chips",               localisation: "Longueil-Sainte-Marie (60126)", bio: false, logo: "assets/logos/SC.png" },
    GRO: { nom: "Grandes marques",         localisation: "",                            bio: false, logo: null }
  },

  softs: [
    // ── Sterne & Mousse ──
    {
      id: "lim-press",
      nom: "Limonade Pression",
      sous_nom: "Li'Mousse",
      description: null,
      volume: null,
      prix: "2,80€",
      prix2: "5,50€",
      format1: "25cL",
      format2: "50cL",
      bio: true,
      fournisseur: "SM",
      photo: null,
      visible: true
    },
    {
      id: "lim-eph",
      nom: "Limonade Éphémère",
      sous_nom: null,
      description: "Pomme / Houblon",
      volume: "33cL",
      prix: "3,20€",
      prix2: null,
      format1: null,
      format2: null,
      bio: true,
      fournisseur: "SM",
      photo: null,
      visible: true
    },
    {
      id: "lim-verv",
      nom: "Limonade Verveine",
      sous_nom: null,
      description: "Infusion verveine peu sucrée · jus de citron jaune",
      volume: "33cL",
      prix: "3,20€",
      prix2: null,
      format1: null,
      format2: null,
      bio: true,
      fournisseur: "SM",
      photo: null,
      visible: true
    },
    // ── Château de la Viaudière ──
    {
      id: "jus-raisin",
      nom: "Pur Jus de Raisin Cabernet",
      sous_nom: null,
      description: "100% Cabernet, sans sucre ajouté",
      volume: "25cL",
      prix: "3,00€",
      prix2: null,
      format1: null,
      format2: null,
      bio: true,
      fournisseur: "CV",
      photo: null,
      visible: true
    },
    // ── Bibibulles ──
    {
      id: "cocoricola",
      nom: "Cocoricola",
      sous_nom: null,
      description: "Cola artisanal français",
      volume: "33cL",
      prix: "2,90€",
      prix2: null,
      format1: null,
      format2: null,
      bio: true,
      fournisseur: "BB",
      photo: null,
      visible: true
    },
    // ── Maison Specht ──
    {
      id: "the-vert",
      nom: "Thé Vert Pêche",
      sous_nom: null,
      description: "Infusion de thé vert BIO & purée de pêche",
      volume: "25cL",
      prix: "2,50€",
      prix2: null,
      format1: null,
      format2: null,
      bio: true,
      fournisseur: "MS",
      photo: null,
      visible: true
    },
    {
      id: "mocktail-yang",
      nom: "Mocktail Madame Yang",
      sous_nom: null,
      description: "Framboise · Litchi · Baies Roses",
      volume: "25cL",
      prix: "4,30€",
      prix2: null,
      format1: null,
      format2: null,
      bio: true,
      fournisseur: "MS",
      photo: null,
      visible: true
    },
    {
      id: "jus-orange",
      nom: "Jus d'Orange Radieuse",
      sous_nom: null,
      description: "Nuances de fleur d'oranger",
      volume: "25cL",
      prix: "3,90€",
      prix2: null,
      format1: null,
      format2: null,
      bio: true,
      fournisseur: "MS",
      photo: null,
      visible: true
    }
  ],

  softs_classiques: [
    { id: "coca-cherry",  nom: "Coca-Cola Cherry",      prix: "2,90€", visible: true },
    { id: "lipton",       nom: "Lipton Ice Tea Pêche",   prix: "2,90€", visible: true },
    { id: "fanta",        nom: "Fanta Orange",            prix: "2,90€", visible: true },
    { id: "oasis",        nom: "Oasis Tropical",          prix: "2,90€", visible: true },
    { id: "perrier",      nom: "Perrier",                 prix: "2,00€", visible: true },
    { id: "evian",        nom: "Evian",                   prix: "2,00€", visible: true }
  ],

  sirops: [
    { nom: "Grenadine",    emoji: "🔴", prix: "+0,20€" },
    { nom: "Menthe verte", emoji: "🟢", prix: "+0,20€" },
    { nom: "Citron jaune", emoji: "🟡", prix: "+0,20€" },
    { nom: "Pêche blanche",emoji: "🍑", prix: "+0,20€" },
    { nom: "Banane-Kiwi",  emoji: "🍌", prix: "+0,20€" }
  ],

  bieres: [
    {
      id: "glouglou",
      nom: "Glouglou",
      description: "Blonde au Sarrasin",
      alcool: "4%",
      prix: "3,00€",
      prix2: "6,00€",
      format1: "25cL",
      format2: "50cL",
      type: "pression",
      bio: true,
      fournisseur: "SM",
      photo: null,
      visible: true
    },
    {
      id: "ephemere-press",
      nom: "Éphémère",
      description: "IPA Carotte · Clémentine · Citron",
      alcool: "6%",
      prix: "3,50€",
      prix2: "7,00€",
      format1: "25cL",
      format2: "50cL",
      type: "pression",
      bio: true,
      fournisseur: "SM",
      photo: null,
      visible: true
    },
    {
      id: "romarin",
      nom: "Romarin Triple",
      description: "Bière aromatisée au romarin",
      alcool: "7,5%",
      volume: "33cL",
      prix: "4,00€",
      prix2: null,
      type: "bouteille",
      bio: true,
      fournisseur: "SM",
      photo: null,
      visible: true
    },
    {
      id: "ephemere-btl",
      nom: "Éphémère",
      description: "Gose Pêche de vigne · Mélisse",
      alcool: "4%",
      volume: "33cL",
      prix: "4,00€",
      prix2: null,
      type: "bouteille",
      bio: true,
      fournisseur: "SM",
      photo: null,
      visible: true
    },
    {
      id: "tartinale",
      nom: "Tartin'Ale",
      description: "Ambrée au pain de boulangerie",
      alcool: "5%",
      volume: "33cL",
      prix: "4,00€",
      prix2: null,
      type: "bouteille",
      bio: true,
      fournisseur: "SM",
      photo: null,
      visible: true
    }
  ],

  vins: [
    {
      id: "cremant",
      nom: "Crémant de Loire — Blanc Brut",
      description: "Effervescent",
      alcool: "12,5%",
      emoji: "🥂",
      couleur_bg: "#F0EBD8",
      prix: "14,90€",
      bio: true,
      fournisseur: "CV",
      photo: null,
      visible: true
    },
    {
      id: "blanc",
      nom: "Vin Blanc — Sauvignon",
      description: "Sec & minéral",
      alcool: "12%",
      emoji: "🍾",
      couleur_bg: "#EDF4E8",
      prix: "12,50€",
      bio: true,
      fournisseur: "CV",
      photo: null,
      visible: true
    },
    {
      id: "rouge",
      nom: "Vin Rouge — Tuilé",
      description: "Charpenté",
      alcool: "12%",
      emoji: "🍷",
      couleur_bg: "#F5E8E8",
      prix: "14,00€",
      bio: true,
      fournisseur: "CV",
      photo: null,
      visible: true
    },
    {
      id: "rose",
      nom: "Vin Rosé — Cabernet d'Anjou",
      description: "Demi-sec & fruité",
      alcool: "11%",
      emoji: "🌸",
      couleur_bg: "#FAEEF4",
      prix: "10,60€",
      bio: true,
      fournisseur: "CV",
      photo: null,
      visible: true
    }
  ],

  snacks_sucres: [
    {
      id: "cookie-caramel",
      nom: "Cookie Cœur Caramel Beurre Salé",
      description: "Cookie Breton artisanal",
      prix: "2,99€",
      fournisseur: "FC",
      photo: null,
      visible: true
    },
    {
      id: "cookie-speculoos",
      nom: "Cookie Cœur Spéculoos",
      description: "Cookie Breton artisanal",
      prix: "2,99€",
      fournisseur: "FC",
      photo: null,
      visible: true
    },
    {
      id: "cookie-ptt",
      nom: "Cookie Tout Choco — Pâte à Tartiner",
      description: "Cookie Breton artisanal",
      prix: "2,99€",
      fournisseur: "FC",
      photo: null,
      visible: true
    },
    {
      id: "cookie-bueno",
      nom: "Cookie Tout Choco — Crème Bueno",
      description: "Cookie Breton artisanal",
      prix: "2,99€",
      fournisseur: "FC",
      photo: null,
      visible: true
    }
  ],

  snacks_sales: [
    {
      id: "chips-nature",
      nom: "Chips Nature",
      description: "40g",
      prix: "1,20€",
      fournisseur: "SC",
      photo: null,
      visible: true
    },
    {
      id: "chips-bbq",
      nom: "Chips Barbecue",
      description: "40g",
      prix: "1,30€",
      fournisseur: "SC",
      photo: null,
      visible: true
    }
  ]

};
