/**
 * app.js — Rush Action Game · Logique de la carte
 * Ce fichier gère l'affichage et le mode édition.
 * Les données sont dans js/data.js
 */

// ═══════════════════════════════════════════
// ÉTAT
// ═══════════════════════════════════════════
let editMode = false;

// ═══════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  renderAll();
  initEditBar();
});

// ═══════════════════════════════════════════
// RENDER PRINCIPAL
// ═══════════════════════════════════════════
function renderAll() {
  renderHeader();
  renderSofts();
  renderBieres();
  renderVins();
  renderSnacks();
}

// ── Header ──
function renderHeader() {
  const cfg = MENU_DATA.config;
  setText('hdr-badge', cfg.badge);
  setText('hdr-titre', cfg.titre);
  setText('hdr-sous-titre', cfg.sous_titre);
  setHTML('footer-text', `<strong>${cfg.footer}</strong><br><span>Prix TTC · TVA incluse</span>`);
}

// ── Softs ──
function renderSofts() {
  // Softs locaux groupés par fournisseur
  const groups = {};
  MENU_DATA.softs.filter(p => p.visible).forEach(p => {
    const k = p.fournisseur;
    if (!groups[k]) groups[k] = [];
    groups[k].push(p);
  });

  const container = document.getElementById('softs-local');
  container.innerHTML = '';

  Object.entries(groups).forEach(([fKey, prods]) => {
    const f = MENU_DATA.fournisseurs[fKey];
    container.appendChild(makeSupBanner(fKey, f));
    const grid = document.createElement('div');
    grid.className = 'products-grid';
    grid.dataset.gridId = 'soft-' + fKey;
    prods.forEach(p => grid.appendChild(makeProductCard(p)));
    container.appendChild(grid);
    container.appendChild(makeAddBtn('soft-' + fKey, () => addProductTo('softs', fKey)));
  });

  // Softs classiques
  const classiqueList = document.getElementById('classic-list');
  classiqueList.innerHTML = '';
  MENU_DATA.softs_classiques.filter(s => s.visible).forEach(s => {
    classiqueList.appendChild(makeClassicItem(s));
  });

  // Sirops
  const siropGrid = document.getElementById('sirop-grid');
  siropGrid.innerHTML = '';
  MENU_DATA.sirops.forEach(s => {
    const div = document.createElement('div');
    div.className = 'sirop-item';
    div.innerHTML = `<span>${s.emoji} <span class="editable" contenteditable="false">${s.nom}</span></span>
                     <span class="sirop-price editable" contenteditable="false">${s.prix}</span>`;
    siropGrid.appendChild(div);
  });
}

// ── Bières ──
function renderBieres() {
  const pression  = MENU_DATA.bieres.filter(b => b.visible && b.type === 'pression');
  const bouteille = MENU_DATA.bieres.filter(b => b.visible && b.type === 'bouteille');
  const f = MENU_DATA.fournisseurs['SM'];

  const container = document.getElementById('bieres-container');
  container.innerHTML = '';
  container.appendChild(makeSupBanner('SM', f));

  const addSec = (label) => {
    const div = document.createElement('div');
    div.className = 'sec-title';
    div.textContent = label;
    container.appendChild(div);
  };

  addSec('• Pression');
  const gPress = document.createElement('div');
  gPress.className = 'products-grid'; gPress.dataset.gridId = 'bieres-press';
  pression.forEach(b => gPress.appendChild(makeProductCard(b, true)));
  container.appendChild(gPress);
  container.appendChild(makeAddBtn('bieres-press', () => addProductTo('bieres', 'SM', 'pression')));

  addSec('• Bouteille 33cL');
  const gBtl = document.createElement('div');
  gBtl.className = 'products-grid'; gBtl.dataset.gridId = 'bieres-btl';
  bouteille.forEach(b => gBtl.appendChild(makeProductCard(b, true)));
  container.appendChild(gBtl);
  container.appendChild(makeAddBtn('bieres-btl', () => addProductTo('bieres', 'SM', 'bouteille')));
}

// ── Vins ──
function renderVins() {
  const f = MENU_DATA.fournisseurs['CV'];
  const container = document.getElementById('vins-container');
  container.innerHTML = '';
  container.appendChild(makeSupBanner('CV', f));

  const list = document.createElement('div');
  list.style.marginTop = '.6rem';
  list.id = 'vins-list';
  MENU_DATA.vins.filter(v => v.visible).forEach(v => list.appendChild(makeWineCard(v)));
  container.appendChild(list);
}

// ── Snacks ──
function renderSnacks() {
  const fFC = MENU_DATA.fournisseurs['FC'];
  const fSC = MENU_DATA.fournisseurs['SC'];

  // Sucrés
  const sucres = document.getElementById('snacks-sucres');
  sucres.innerHTML = '';
  sucres.appendChild(makeSupBanner('FC', fFC));
  const gS = document.createElement('div');
  gS.className = 'products-grid'; gS.dataset.gridId = 'snacks-sucres';
  MENU_DATA.snacks_sucres.filter(s => s.visible).forEach(s => gS.appendChild(makeProductCard(s)));
  sucres.appendChild(gS);
  sucres.appendChild(makeAddBtn('snacks-sucres', () => addProductTo('snacks_sucres', 'FC')));

  // Salés
  const sales = document.getElementById('snacks-sales');
  sales.innerHTML = '';
  sales.appendChild(makeSupBanner('SC', fSC));
  const gA = document.createElement('div');
  gA.className = 'products-grid'; gA.dataset.gridId = 'snacks-sales';
  MENU_DATA.snacks_sales.filter(s => s.visible).forEach(s => gA.appendChild(makeProductCard(s)));
  sales.appendChild(gA);
  sales.appendChild(makeAddBtn('snacks-sales', () => addProductTo('snacks_sales', 'SC')));
}

// ═══════════════════════════════════════════
// COMPOSANTS HTML
// ═══════════════════════════════════════════

function makeSupBanner(key, f) {
  const div = document.createElement('div');
  div.className = 'sup-banner';
  const logoHtml = f.logo
    ? `<img class="sup-logo" src="${f.logo}" alt="${f.nom}">`
    : `<div class="sup-logo" style="background:#eee;display:flex;align-items:center;justify-content:center;font-size:1.2rem">🏭</div>`;
  div.innerHTML = `
    ${logoHtml}
    <div class="sup-info">
      <h3 class="editable" contenteditable="false">${f.nom}</h3>
      <p class="editable" contenteditable="false">${f.localisation}</p>
    </div>
    ${f.bio ? '<div class="bio-badge">🌿 Bio</div>' : ''}`;
  return div;
}

function makeProductCard(p, isBiere = false) {
  const div = document.createElement('div');
  div.className = 'product-card';
  div.dataset.prodId = p.id;

  const bioHtml = p.bio ? '<div class="bio-pill">BIO</div>' : '';
  const sous = p.sous_nom ? `<div class="prod-sous editable" contenteditable="false">${p.sous_nom}</div>` : '';
  const desc = p.description ? `<div class="prod-desc editable" contenteditable="false">${p.description}</div>` : '';
  const vol = p.volume ? `<div class="prod-vol">📦 ${p.volume}</div>` : '';
  const alc = isBiere && p.alcool ? `<span class="price-tag alc">${p.alcool}</span>` : '';

  let pricesHtml = '';
  if (p.prix2) {
    pricesHtml = `<span class="price-tag editable" contenteditable="false">${p.format1 || '25cL'} — ${p.prix}</span>
                  <span class="price-tag editable" contenteditable="false">${p.format2 || '50cL'} — ${p.prix2}</span>`;
  } else {
    pricesHtml = `<span class="price-tag main editable" contenteditable="false">${p.prix}</span>`;
  }

  const imgHtml = `
    <div class="prod-img-wrap" onclick="editModeImgClick(this)">
      ${p.photo ? `<img src="${p.photo}" alt="${p.nom}">` : `<div class="prod-img-placeholder">🍹</div>`}
      <div class="prod-img-btn">📷 Photo</div>
    </div>`;

  div.innerHTML = `
    <div class="card-edit-row">
      <button class="ceb" onclick="uploadCardImg(this)">📷</button>
      <button class="ceb" onclick="toggleBio(this)">🌿 Bio</button>
      <button class="ceb del" onclick="removeCard(this)">✕</button>
    </div>
    ${imgHtml}
    ${bioHtml}
    <div class="prod-name editable" contenteditable="false">${p.nom}</div>
    ${sous}${desc}${vol}
    <div class="prod-prices">${pricesHtml}${alc}</div>`;

  return div;
}

function makeWineCard(v) {
  const div = document.createElement('div');
  div.className = 'wine-card';
  div.innerHTML = `
    <div class="wine-dot" style="background:${v.couleur_bg}">${v.emoji}</div>
    <div class="wine-info">
      <h4 class="editable" contenteditable="false">${v.nom}</h4>
      <p class="editable" contenteditable="false">${v.description} · Bio · ${v.alcool}</p>
    </div>
    <div class="wine-price editable" contenteditable="false">${v.prix}</div>`;
  return div;
}

function makeClassicItem(s) {
  const div = document.createElement('div');
  div.className = 'classic-item';
  div.innerHTML = `
    <span class="classic-name editable" contenteditable="false">${s.nom}</span>
    <span style="display:flex;align-items:center;gap:.4rem">
      <span class="classic-price editable" contenteditable="false">${s.prix}</span>
      <button class="ceb del" onclick="this.closest('.classic-item').remove()" style="display:none">✕</button>
    </span>`;
  return div;
}

function makeAddBtn(gridId, fn) {
  const btn = document.createElement('button');
  btn.className = 'add-prod-btn';
  btn.textContent = '+ Ajouter un produit';
  btn.onclick = fn || (() => addProductToGrid(gridId));
  return btn;
}

// ═══════════════════════════════════════════
// EDIT MODE
// ═══════════════════════════════════════════
function initEditBar() {
  document.getElementById('editToggle').addEventListener('click', () => {
    if (editMode) deactivateEdit();
    else showPwdOverlay();
  });
}

function showPwdOverlay() {
  document.getElementById('pwdOverlay').classList.remove('hidden');
  document.getElementById('pwdInput').value = '';
  document.getElementById('pwdError').textContent = '';
  setTimeout(() => document.getElementById('pwdInput').focus(), 100);
}

function checkPwd() {
  const val = document.getElementById('pwdInput').value;
  if (val === MENU_DATA.config.mot_de_passe_edition) {
    document.getElementById('pwdOverlay').classList.add('hidden');
    activateEdit();
  } else {
    document.getElementById('pwdError').textContent = '❌ Mot de passe incorrect';
    document.getElementById('pwdInput').value = '';
    document.getElementById('pwdInput').focus();
  }
}

function closePwd() {
  document.getElementById('pwdOverlay').classList.add('hidden');
}

function activateEdit() {
  editMode = true;
  document.body.classList.add('edit-mode');
  document.getElementById('editBar').classList.add('active');
  document.getElementById('editToggle').textContent = '🔒 Verrouiller';
  document.getElementById('editToggle').classList.add('on');
  document.getElementById('editHint').textContent = 'Cliquez sur un texte ou une photo pour modifier';
  document.getElementById('saveBtn').style.display = 'inline-block';
  document.getElementById('floatToolbar').classList.add('visible');
  document.querySelectorAll('.editable').forEach(el => el.contentEditable = 'true');
  showToast('✏️ Mode édition activé');
}

function deactivateEdit() {
  editMode = false;
  document.body.classList.remove('edit-mode');
  document.getElementById('editBar').classList.remove('active');
  document.getElementById('editToggle').textContent = '✏️ Modifier';
  document.getElementById('editToggle').classList.remove('on');
  document.getElementById('editHint').textContent = 'Activez le mode édition pour modifier la carte';
  document.getElementById('saveBtn').style.display = 'none';
  document.getElementById('floatToolbar').classList.remove('visible');
  document.querySelectorAll('.editable').forEach(el => el.contentEditable = 'false');
  showToast('✅ Modifications enregistrées');
}

// ── Images ──
function editModeImgClick(wrap) {
  if (!editMode) return;
  triggerImgUpload(wrap);
}

function uploadCardImg(btn) {
  const wrap = btn.closest('.product-card').querySelector('.prod-img-wrap');
  triggerImgUpload(wrap);
}

function triggerImgUpload(wrap) {
  const input = document.createElement('input');
  input.type = 'file'; input.accept = 'image/*';
  input.onchange = e => {
    const file = e.target.files[0]; if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      wrap.innerHTML = `<img src="${ev.target.result}" alt="photo"><div class="prod-img-btn">📷 Changer</div>`;
      showToast('Photo ajoutée ✅');
    };
    reader.readAsDataURL(file);
  };
  input.click();
}

// ── Toggle BIO ──
function toggleBio(btn) {
  const card = btn.closest('.product-card');
  const existing = card.querySelector('.bio-pill');
  if (existing) existing.remove();
  else {
    const pill = document.createElement('div');
    pill.className = 'bio-pill'; pill.textContent = 'BIO';
    card.querySelector('.card-edit-row').insertAdjacentElement('afterend', pill);
  }
}

// ── Remove card ──
function removeCard(btn) {
  if (!editMode) return;
  if (confirm('Supprimer ce produit ?')) {
    btn.closest('.product-card').remove();
    showToast('Produit supprimé');
  }
}

// ── Add product ──
function addProductToGrid(gridId) {
  const grid = document.querySelector(`[data-grid-id="${gridId}"]`);
  if (!grid) return;
  const p = { id: 'new-' + Date.now(), nom: 'Nouveau produit', description: 'Description', prix: '0,00€', bio: false, photo: null, visible: true };
  const card = makeProductCard(p);
  grid.appendChild(card);
  card.querySelector('.prod-name').focus();
  showToast('Produit ajouté ✅');
}

function addProductTo(category, fKey, type) {
  const p = {
    id: 'new-' + Date.now(), nom: 'Nouveau produit', description: 'Description',
    prix: '0,00€', bio: false, photo: null, visible: true,
    fournisseur: fKey, type: type || null
  };
  const key = type === 'pression' ? 'bieres-press' : (type === 'bouteille' ? 'bieres-btl' : category + '-' + fKey.toLowerCase());
  addProductToGrid(key);
}

function addSoftClassique() {
  const list = document.getElementById('classic-list');
  const s = { id: 'new-' + Date.now(), nom: 'Nouveau soft', prix: '2,90€', visible: true };
  const item = makeClassicItem(s);
  list.appendChild(item);
  item.querySelector('.editable').contentEditable = 'true';
  item.querySelector('.editable').focus();
  item.querySelector('.ceb.del').style.display = 'inline-block';
  showToast('Soft ajouté ✅');
}

// ═══════════════════════════════════════════
// NAVIGATION
// ═══════════════════════════════════════════
function showSec(n, b) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('visible'));
  document.querySelectorAll('.nav-btn').forEach(x => x.classList.remove('active'));
  document.getElementById('sec-' + n).classList.add('visible');
  b.classList.add('active');
}
function showSub(n, b) {
  document.querySelectorAll('#sec-boissons .sub-s').forEach(s => s.classList.remove('visible'));
  document.querySelectorAll('.sub-btn').forEach(x => x.classList.remove('active'));
  document.getElementById('sub-' + n).classList.add('visible');
  b.classList.add('active');
}
function showSnk(n, b) {
  document.querySelectorAll('#sec-snacks .sub-s').forEach(s => s.classList.remove('visible'));
  document.querySelectorAll('.snk-btn').forEach(x => x.classList.remove('active'));
  document.getElementById('snk-' + n).classList.add('visible');
  b.classList.add('active');
}
function toggleSirops() {
  const p = document.getElementById('sirops-panel');
  const a = document.getElementById('sarr');
  p.classList.toggle('open');
  a.textContent = p.classList.contains('open') ? '▲' : '▼';
}

// ═══════════════════════════════════════════
// UTILITAIRES
// ═══════════════════════════════════════════
function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}
function setHTML(id, val) {
  const el = document.getElementById(id);
  if (el) el.innerHTML = val;
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2200);
}
